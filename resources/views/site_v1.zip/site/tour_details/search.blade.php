@extends('layouts.site.app')

@section('content')

    @php
        if(request('type')){
            $img=App\Models\Category::find(request('type'))->banner;
        }else{
            $img =App\Models\Setting::firstWhere('option_key', \App\Enums\SettingKey::SEARCH_IMG->value)?->option_value[0] ??'';
        }
    @endphp
    <style>
        .select2-container .select2-selection--single {
            max-width: 61px;
            height: 50px;
        }
        .banner figure {
            background-position: center center;
            background-size: cover !important;
            background-repeat: no-repeat !important;
            height: 50vh;
            transition: all 1s;
            background: linear-gradient(150deg, #00000093 40%, #00000018 70%),
                url("{{ $img }}");

        }

        .banner figcaption {
            top: 80%;
            left: 50%;
            transform: translate(-50%, -80%);
        }

        .banner figure:hover {
            background-position: center center;
            background-size: cover !important;
            background-repeat: no-repeat !important;
            background: linear-gradient(150deg, #00000018 40%, #00000018 70%),
                url("{{ $img }}");
        }
    </style>
    <section class="banner">
        <div class="container-fluid">
            <figure class="position-relative" style="background: linear-gradient(150deg, #00000093 40%, #00000018 70%), url('{{ $category->banner ?? asset("storage/media/siwa (78).png") }}') !important">
                <figcaption class="position-absolute">
                    <div class="text-capitalize">
                        <h2 class="text-white h1">{{ $category->title }}</h2>
                        <p class="text-white">
                            <span class="textMainColor me-1">{{ __('main.home') }}</span>
                            > {{ $category->title }}
                        </p>
                    </div>
                </figcaption>
            </figure>
        </div>
    </section>

    <section class="my-5 filterTour">
        <div class="container">
                @if ($tours->isNotEmpty())
                    <div class="row gy-4">
                        @foreach ($tours as $tour)
                            <div class="col-lg-4 mix Milano Tokyo London">
                                <a href="{{ route('site.tour_details', $tour->slug) }}">
                                    <div class="mx-3 shadow rounded-2 cPointer overflow-hidden">
                                        <figure class="position-relative">
                                            <img src="{{ $tour->featured_image }}" class="w-100 h205" alt="" />
                                            <div
                                                class="imgLayer d-flex justify-content-between align-items-center font-sm">
{{--                                                <div class="text-white p-1 rounded-2">Featured</div>--}}
                                                <div>
                                                    <span class="mx-2 bg-dark text-white p-1 rounded-2">
                                                        <i class="fa me-1 fa-camera"></i>5
                                                    </span>
                                                    <span class="mx-2 bg-dark text-white p-1 rounded-2">
                                                        <i class="fa me-1 fa-photo-video"></i>5
                                                    </span>
                                                </div>
                                            </div>
                                        </figure>
                                        <figcaption class="mt-0 position-relative">
                                            <div class="decs p-3">
                                                <i class="textMainColor me-1 fa fa-location-dot"></i>
                                                @foreach ($tour->destinations as $index => $des)
                                                    <span class="text-secondary text-capitalize">
                                                        @if ($index > 0)
                                                            ,
                                                        @endif{{ $des->title }}
                                                    </span>
                                                @endforeach

                                                <h3 class="h6 mt-2">{{ $tour->title }}</h3>

                                                <div>
                                                    <i class="fa fa-star ratingColor"></i>
                                                    <i class="fa fa-star ratingColor"></i>
                                                    <i class="fa fa-star ratingColor"></i>
                                                    <i class="fa fa-star ratingColor"></i>
                                                    <i class="fa fa-star ratingColor"></i>
                                                    <span class="text-secondary ms-2"> (1{{ __('site.review') }}) </span>
                                                </div>

                                                <div class="mt-2">
                                                    <span class="me-3">
                                                        <i class="textMainColor me-1 fa fa-clock-rotate-left"></i>
                                                        <span
                                                            class="text-secondary text-capitalize">{{ $tour->days->count() }}</span>
                                                    </span>
                                                    <span>
                                                        <i class="textMainColor me-1 fa fa-user-plus"></i>
                                                        <span class="text-secondary text-capitalize">12 {{ __('site.person') }}</span>
                                                    </span>
                                                </div>

                                                <hr />
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div>
                                                        {{ __('site.from') }}
                                                        <span
                                                            class="textMainColor">{{ $tour->start_from_price }}{{ user_currency()->symbol }}</span>
                                                    </div>
                                                    <i class="fa-regular fa-bookmark textMainColor"></i>
                                                </div>
                                            </div>
                                            <div class="trend sDiv shadow px-3 py-1 rounded-2">
                                                <div>
                                                  {{$tour->title}}
                                                </div>
                                            </div>
                                        </figcaption>
                                    </div>
                                </a>
                            </div>
                        @endforeach

                    </div>
                @if($tours->hasPages())
                        <div class="pagination d-flex justify-content-center flex-wrap my-5 pt-3">
                            @if ($tours->onFirstPage())
                                <span class="btn secBtn me-2 px-3 mb-2 disabled" aria-disabled="true">
                                <i class="fa-solid fa-angles-left"></i>
                            </span>
                            @else
                                <a class="btn secBtn me-2 px-3 mb-2" href="{{ $tours->previousPageUrl() }}">
                                    <i class="fa-solid fa-angles-left"></i>
                                </a>
                            @endif

                            @foreach ($tours->getUrlRange(1, $tours->lastPage()) as $page => $url)
                                <a class="btn secBtn me-2 px-3 mb-2{{ $tours->currentPage() == $page ? ' active' : '' }}"
                                   href="{{ $url }}">{{ $page }}</a>
                            @endforeach

                            @if ($tours->hasMorePages())
                                <a class="btn secBtn me-2 px-3 mb-2" href="{{ $tours->nextPageUrl() }}">
                                    <i class="fa-solid fa-angles-right"></i>
                                </a>
                            @else
                                <span class="btn secBtn me-2 px-3 mb-2 disabled" aria-disabled="true">
                                <i class="fa-solid fa-angles-right"></i>
                            </span>
                            @endif
                        </div>
                @endif
        @else
            <h3>{{ __('site.no_tours_found') }}</h3>
            @endif
        </div>
    </section>
@endsection
@push('js')
    <script>
        $(document).ready(function() {
            // Attach change event listener to select tags
            $('#Duration').change(function() {
                $('#Filter').submit();
            });

            $('#type-filter').change(function() {
                console.log("Type changed");
                $('#Filter').submit();
            });

            $('#destination-filter').change(function() {
                $('#Filter').submit();
            });
        });
    </script>
@endpush
