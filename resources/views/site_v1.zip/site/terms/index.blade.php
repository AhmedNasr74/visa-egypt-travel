@extends('layouts.site.app')

@section('content')

    <!-- ================= Day Tour start ========================= -->
    <section class="banner">
        <div class="container-fluid">
            <figure class="position-relative">
                <!-- <img
                        src="{{ asset('assets/site/img/banner.png') }}"
                        class="w-100 h-75"
                        alt="about us banner image"
                      /> -->
                <figcaption class="position-absolute">
                    <div class="text-capitalize">
                        <h2 class="text-white h1">{{ __('site.terms_conditions') }}</h2>
                        <p class="text-white">
                            <a href="{{route("site.home")}}">
                                <span class="textMainColor me-1">{{ __('main.home') }}</span>
                            </a> >{{ __('site.terms_conditions') }}
                        </p>
                    </div>
                </figcaption>
            </figure>
        </div>
    </section>
    <section class="py-5">
        <div class="container">
            <div class="row">
                @php
                $terms = setting(App\Enums\SettingKey::TERMS_AND_CONDITIONS->value);
               @endphp
            {!!$terms[0]!!}
            </div>
        </div>
    </section>

    <!-- ========================= End Day Tour Section ============ -->
@endsection
@push('js')
    <script src="{{ asset('assets/site/js/aboutSlider.js') }}"></script>
@endpush
