@extends('layouts.site.app')

@section('content')
    <style>
        .banner figure {
            background: linear-gradient(150deg, #00000093 40%, #00000018 70%),
            url("{{$des->banner ?? ''}}");
            background-position: center center;
            background-size: cover;
            background-repeat: no-repeat;
            height: 50vh;
            transition: all 1s;
        }

        .banner figcaption {
            top: 80%;
            left: 50%;
            transform: translate(-50%, -80%);
        }

        .banner figure:hover {
            background: linear-gradient(150deg, #00000018 40%, #00000018 70%),
            url("{{$des->banner ?? ''}}");
        }

        .text-brown {
            color: #5c3b16;
        }

        /* Hover animation for image */
        .tour-card-img {
            transition: transform 0.4s ease;
        }

        .tour-card:hover .tour-card-img {
            transform: scale(1.05);
        }

        .card-hover {
            transition: box-shadow 0.3s ease;
        }

        .card-hover:hover {
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15) !important;
        }
    </style>

    <!-- ============ Banner ============ -->
    <section class="banner">
        <div class="container-fluid">
            <figure class="position-relative">
                <figcaption class="position-absolute">
                    <div class="text-capitalize">
                        <h2 class="text-white">{{ $des->title }}</h2>
                        <p class="text-white">
                            <a href="{{ route("site.home") }}">
                                <span class="textMainColor me-1">{{ __('site.home') }}</span>
                            </a>
                            > {{ $des->title }}
                        </p>
                    </div>
                </figcaption>
            </figure>
        </div>
    </section>

    <!-- ============ Description & Tours ============ -->
    <section class="tourDetails py-5">
        <div class="container">
            <div class="row justify-content-center g-4">
                <div class="col-lg-12">
                    <div class="descriptionTour">
                        <!-- Description -->
                        <div class="mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <i class="bx bx-edit-alt me-2"></i>
                                <h5 class="mb-0 fw-semibold">{{ __('site.description') }}</h5>
                            </div>
                            <p class="text-muted">{!! $des->description !!}</p>
                        </div>

                        <!-- Gallery -->
                        @if($des->gallery)
                            <div id="t_gallery" class="my-5">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="bx bx-images me-2"></i>
                                    <h5 class="fw-semibold mb-0">{{ __('site.gallery') }}</h5>
                                </div>

                                <div id="default-carousel" class="relative w-full" data-carousel="slide">
                                    <div class="relative h-56 overflow-hidden rounded-lg md:h-96">
                                        @forelse ($des->gallery as $i => $pic)
                                            <div class="hidden duration-700 ease-in-out" data-carousel-item>
                                                <img src="{{ $pic }}" class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
                                            </div>
                                        @empty
                                            <h3>{{ __('site.no_available_gallery') }}</h3>
                                        @endforelse
                                    </div>
                                </div>
                            </div>
                        @endif

                        <!-- Tours -->
                        @if ($des->tours->isNotEmpty())
                            <div class="row g-4">
                                @foreach ($des->tours as $tour)
                                    <div class="col-md-6 col-xl-4">
                                        <div class="border rounded-lg shadow-sm bg-white overflow-hidden position-relative h-100 d-flex flex-column card-hover tour-card">
                                            <a href="{{ route('site.tour_details', $tour->slug) }}" class="text-decoration-none text-dark">
                                                <div class="position-relative">
                                                    <img src="{{ $tour->featured_image }}" class="w-100 tour-card-img" alt="{{ $tour->title }}" style="height: 220px; object-fit: cover;">
                                                    <span class="position-absolute top-0 start-0 bg-dark text-white px-2 py-1 m-2 rounded">{{ __('site.featured') }}</span>
                                                    <button type="button" class="position-absolute top-0 end-0 m-2 bg-light border-0 rounded-circle p-2">
                                                        <i class="fa fa-heart text-secondary"></i>
                                                    </button>
                                                </div>
                                            </a>
                                            <div class="p-3 flex-grow-1 d-flex flex-column justify-content-between">
                                                <div class="mb-3">
                                                    <h5 class="fw-semibold text-brown">{{ \Illuminate\Support\Str::limit($tour->title, 60) }}</h5>
                                                    <p class="mb-2 text-muted small">{{ __('site.from') }} <span class="text-warning fw-bold">{{ $tour->start_from_price }}{{ user_currency()->symbol }}</span></p>
                                                </div>
                                                <div class="d-flex justify-content-between align-items-center bg-warning bg-opacity-10 p-2 rounded">
                                                    <div class="text-muted small">
                                                        <i class="fa fa-clock me-1 text-warning"></i>
                                                        {{ $tour->days->count() }} {{ __('site.days') }}
                                                        <i class="fa fa-user ms-2 me-1 text-warning"></i>
                                                        1
                                                    </div>
                                                    <a href="{{ route('site.tour_details', $tour->slug) }}" class="btn btn-dark btn-sm">
                                                        {{ __('site.explore') }} <i class="fa fa-arrow-right ms-1"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <h3>{{ __('site.no_tours_found') }}</h3>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('js')
    <script src="{{ asset('assets/site/js/main.js') }}"></script>
@endpush
